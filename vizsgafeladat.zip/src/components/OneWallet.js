import {Button, Card, CardActions, CardContent, Grid, IconButton, Typography} from "@mui/material";
import {Favorite, FavoriteBorder, Delete} from '@mui/icons-material';
import {useNavigate} from "react-router-dom";
import useLike from "../hooks/useLike";
import {FaMoneyBill, FaShareAlt, FaLock, FaLockOpen} from 'react-icons/fa';
import {useAuth} from "../hooks/useAuth";
import {MODALS, useModals} from "../hooks/useModal";


export default function OneWallet({id, name, description, balance}) {
    const navigate = useNavigate();
    const {showModal} = useModals();
    const [isLiked, onChangeLike] = useLike(id);
    const {sessionUser, authToken} = useAuth();

    function onLock() {
        if (authToken === false) {
            // show login modal
            showModal(MODALS.LOGIN);
            return;
        } else {
            navigate(`/transaction/${id}`);  
        } 
    }

    function onDonate() {
        if (authToken === false) {
            // show login modal
            showModal(MODALS.LOGIN);
            return;
        } else {
            navigate(`/transaction/${id}`);  
        } 
    }

    return (<Grid item xs={12} md={4} lg={3}>
        <Card>
            <CardContent>
                <Typography variant={"h4"}>
                    {name}
                </Typography>
                <Typography variant={"body1"}>
                    {description}<br/>
                    Donated: {balance} $<br/>
                </Typography>
            </CardContent>
            <CardActions>
                <Button size="small" variant={"outlined"} fullWidth onClick={() => {
                    navigate(`/wallet/${id}`);
                }}>Details</Button>
                <IconButton onClick={() => onChangeLike()}>
                    {isLiked ? <Favorite/> : <FavoriteBorder/>}
                </IconButton>
                {onLock && <IconButton onClick={() => onLock()}>
                    <Delete/>
                </IconButton>}
                
                {sessionUser.admin ? (<IconButton aria-label="Close wallet" > <FaLockOpen/></IconButton>) : ''}

                <IconButton aria-label="Donate" onClick={() => onDonate()} >
                    <FaMoneyBill/>
                </IconButton>
                <IconButton aria-label="Send url" onClick={() => {navigate(`/send/${id}`) }} >
                    <FaShareAlt/>
                </IconButton>
            </CardActions>
        </Card>
    </Grid>);
}