import {AppBar, Box, Button, Toolbar, Typography} from "@mui/material";
import {useNavigate} from 'react-router-dom';
import * as React from "react";
import {useAuth} from "../hooks/useAuth";
import {useModals, MODALS} from "../hooks/useModal";
import {FaUser} from 'react-icons/fa';

export default function AppMenu() {

  const navigate = useNavigate();
  const {showModal} = useModals();
  const {authToken, logout, sessionUser} = useAuth();

  return (
    <Box>
      <AppBar position="static">
        <Toolbar>          
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }} onClick={() => {
              navigate("/");
            }}>Charity Wallets</Typography>

          {authToken === false && (<>
            <Button color="inherit" onClick={() => {
                showModal(MODALS.LOGIN);
            }}>Login</Button>

            <Button color="inherit" onClick={() => {
                showModal(MODALS.REG);
            }}>Reg</Button>
          </>)}
          {authToken !== false && (<>
            <Button color="inherit" onClick={() => {
                navigate("/me");
            }}>
              My wallets
            </Button>
            <Button color="inherit" onClick={logout}>Logout</Button>

            <Typography variant="h6" component="div" ><FaUser/>{sessionUser.name} </Typography>
          </>)}

        </Toolbar>
      </AppBar>
    </Box>
  );
}