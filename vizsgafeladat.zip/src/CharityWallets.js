import * as React from 'react';
import { createTheme } from "@mui/material";
import ListWalletsScreen from './screens/list/ListWalletsScreen';

const theme = createTheme({

});

export default function CharityWallets() {
  return (<ListWalletsScreen />)
};
